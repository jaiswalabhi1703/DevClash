import sys;

def add(a):
  # enter your code here
  return 35

if __name__ == "__main__":
  a = int(sys.argv[1])
  result = int(sys.argv[2])
  print(add(a) == result)
