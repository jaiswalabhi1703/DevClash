# DevsClash
It was an attempt to create a competitive programming platform where a  coder can battle 1 on 1 with another coder. Each battle will have an Entry fee. and the winner will get a cash prize from the collected pool of money.
Multiple coders can also join/create a coding room.

# Demo
Visit www.devsclash.com to try the platform.
Currently, the UX is not that great. The website is slow. and there are only 2 questions uploaded.

To run it on your machine, clone this repo. 

# contribute
If you'd like to contribute. You can add questions/problems.
Add your questions in Questions/question.js in this format

//...................................

[Q_id, Topic, Statement, Testcases]

//...................................

Q_id (String): Question id in this format 'username-Q_no'. Here username is your GitHub username and Q_no is the serial no of the question uploaded by you. 

Topic (String): array/string/...

Statement (String): Explanation of the problem with the examples

Testcases (Array of Array): [testcase-1, testcase-2, testcase-3, ...] Here each test case is an array in itself where the last element is the desired result and all other elements are arguments for the given questions


