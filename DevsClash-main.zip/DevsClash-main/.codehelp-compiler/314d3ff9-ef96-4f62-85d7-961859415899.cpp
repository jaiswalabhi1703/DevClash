#include <iostream>
#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main() {
	cout<<"helloworold"<<endl;
	return 0;
}